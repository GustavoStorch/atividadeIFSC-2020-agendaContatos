package br.com.gstorch.agendacontatos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import br.com.gstorch.agendacontatos.ui.main.MainFragment;

public class MainActivity extends AppCompatActivity {

    public static final String CONTACT_ID = "CONTACT_ID";
    public static int NEW_CONTACT = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
    }
}