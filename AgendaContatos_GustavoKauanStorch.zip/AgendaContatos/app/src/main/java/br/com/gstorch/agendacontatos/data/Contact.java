package br.com.gstorch.agendacontatos.data;

public class Contact {
    private int id;
    private String nome;
    private String phone;
    private String email;

    public Contact(int id, String nome, String phone, String email) {
        this.id = id;
        this.nome = nome;
        this.phone = phone;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }
}
