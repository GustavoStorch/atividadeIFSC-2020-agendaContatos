package br.com.gstorch.agendacontatos.ui.main;

import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import br.com.gstorch.agendacontatos.R;

import static br.com.gstorch.agendacontatos.MainActivity.CONTACT_ID;
import static br.com.gstorch.agendacontatos.MainActivity.NEW_CONTACT;

public class AddEditFragment extends Fragment {
    private int contactID;
    private boolean addingNewContact;
    private FloatingActionButton saveContactFAB;

    private AddEditViewModel addEditViewModel;

    public static AddEditFragment newInstance() {
        return new AddEditFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_edit_fragment, container, false);

        saveContactFAB = view.findViewById(R.id.saveButton);
        saveContactFAB.setOnClickListener(saveContactButtonClicked);
        
        Bundle arguments = getArguments();
        contactID = arguments.getInt(CONTACT_ID);
        if (contactID == NEW_CONTACT) {
            addingNewContact = true;
        } else {
            addingNewContact = false;
        }
        return view;
    }

    private final View.OnClickListener saveContactButtonClicked = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            ((InputMethodManager) getActivity().getSystemService(
                    Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getView().getWindowToken(), 0);
            saveContact();
        }
    };

    private void saveContact() {
        Navigation.findNavController(getView()).popBackStack();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        addEditViewModel = new ViewModelProvider(this).get(AddEditViewModel.class);
        // TODO: Use the ViewModel
    }

}