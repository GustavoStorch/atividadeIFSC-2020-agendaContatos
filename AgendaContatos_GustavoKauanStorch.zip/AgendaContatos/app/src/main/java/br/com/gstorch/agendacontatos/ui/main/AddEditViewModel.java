package br.com.gstorch.agendacontatos.ui.main;

import androidx.lifecycle.ViewModel;

public class AddEditViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}