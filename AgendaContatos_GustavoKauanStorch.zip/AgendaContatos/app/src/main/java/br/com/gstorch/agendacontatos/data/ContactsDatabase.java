package br.com.gstorch.agendacontatos.data;

public class ContactsDatabase {
}
