package br.com.gstorch.agendacontatos.ui.main;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import br.com.gstorch.agendacontatos.R;
import br.com.gstorch.agendacontatos.data.Contact;

import static br.com.gstorch.agendacontatos.MainActivity.CONTACT_ID;
import static br.com.gstorch.agendacontatos.MainActivity.NEW_CONTACT;

public class MainFragment extends Fragment {

    ContactsAdapter contactsAdapter;

    private MainViewModel mainViewModel;

    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerVIew);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity().getBaseContext()));
        recyclerView.addItemDecoration(new ItemDivider(getContext()));

        contactsAdapter = new ContactsAdapter(new ContactsAdapter.ContactClickListener() {
            @Override
            public void onClick(int contactID) {
                onContactSelected(contactID);
            }
        });
        recyclerView.setAdapter(contactsAdapter);

        FloatingActionButton addButton = view.findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddContact();
            }
        });

        return view;
    }

    private void onAddContact() {
        Bundle arguments = new Bundle();
        arguments.putInt(CONTACT_ID, NEW_CONTACT);

        Navigation.findNavController(getView()).navigate(R.id.action_mainFragment_to_addEditFragment, arguments);
    }

    private void onContactSelected(int contact_ID) {
        Bundle arguments = new Bundle();
        arguments.putInt(CONTACT_ID, contact_ID);

        Navigation.findNavController(getView()).navigate(R.id.action_mainFragment_to_detailFragment, arguments);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mainViewModel = new ViewModelProvider(this).get(MainViewModel.class);
        // TODO: Use the ViewModel

        ArrayList<Contact> list = new ArrayList<Contact>();
        list.add(new Contact(1, "Gustavo", "98448-0062", "gustavo@gmail.com"));
        list.add(new Contact(2, "Bruno", "3370-0063", "bruno@gmail.com"));
        list.add(new Contact(3, "Marlon", "3376-0214", "marlon@gmail.com"));

        contactsAdapter.setContacts(list);
    }

}